package com.dooropener.app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    // ================================================================
    // এখানে আপনার Door open করার URL টি বসানো আছে।
    // IP address বা path পরিবর্তন করতে চাইলে শুধু এই লাইনটি এডিট করুন।
    // ================================================================
    private static final String DOOR_URL = "http://192.168.68.106/form/Device?act=9";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private TextView statusText;
    private Button openDoorButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        openDoorButton = findViewById(R.id.openDoorButton);

        openDoorButton.setOnClickListener(v -> triggerDoor());

        // অ্যাপ ওপেন হওয়ার সাথে সাথে স্বয়ংক্রিয়ভাবে দরজা খোলার রিকোয়েস্ট পাঠানো হবে
        triggerDoor();
    }

    private void triggerDoor() {
        statusText.setText("দরজা খোলার রিকোয়েস্ট পাঠানো হচ্ছে...");
        openDoorButton.setEnabled(false);

        executor.execute(() -> {
            boolean success = false;
            String message;
            try {
                URL url = new URL(DOOR_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                InputStream is = (responseCode >= 200 && responseCode < 300)
                        ? conn.getInputStream() : conn.getErrorStream();
                if (is != null) {
                    is.close();
                }
                success = (responseCode >= 200 && responseCode < 300);
                message = success
                        ? "দরজা খোলা হয়েছে! (HTTP " + responseCode + ")"
                        : "সমস্যা হয়েছে (HTTP " + responseCode + ")";
            } catch (Exception e) {
                message = "সংযোগ ব্যর্থ হয়েছে: " + e.getMessage()
                        + "\nWiFi/Network ঠিক আছে কিনা চেক করুন।";
            }

            final String finalMessage = message;
            runOnUiThread(() -> {
                statusText.setText(finalMessage);
                openDoorButton.setEnabled(true);
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
