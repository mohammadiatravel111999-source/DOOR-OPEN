# Door Opener App - তৈরির নির্দেশনা

## এই অ্যাপটি কী করে
অ্যাপ ওপেন হলেই স্বয়ংক্রিয়ভাবে এই URL-এ রিকোয়েস্ট পাঠায়:
```
http://192.168.68.106/form/Device?act=9
```
সাথে একটা বড় "OPEN DOOR" বাটনও আছে, চাইলে আবার চাপ দিয়ে দরজা খুলতে পারবেন।

## APK বানানোর ধাপ (Android Studio দিয়ে)

1. **Android Studio ইন্সটল করুন** (যদি না থাকে): https://developer.android.com/studio
2. Android Studio ওপেন করে **Open** করুন এই ফোল্ডারটা (`DoorOpener`)
3. প্রথমবার Gradle sync হতে কিছুক্ষণ সময় লাগবে (ইন্টারনেট লাগবে)
4. উপরের মেনু থেকে **Build > Build Bundle(s) / APK(s) > Build APK(s)** ক্লিক করুন
5. Build শেষ হলে নিচে একটা notification আসবে "locate" লিংক সহ — ওখানে ক্লিক করলে APK ফাইল পাবেন
   (সাধারণত: `app/build/outputs/apk/debug/app-debug.apk`)
6. এই APK ফাইলটা ফোনে কপি করে ইন্সটল করুন (Settings > Security তে "Unknown apps" ইন্সটল অনুমতি দিতে হতে পারে)

## IP/URL পরিবর্তন করতে চাইলে
`app/src/main/java/com/dooropener/app/MainActivity.java` ফাইলে এই লাইনটা খুঁজুন:
```java
private static final String DOOR_URL = "http://192.168.68.106/form/Device?act=9";
```
এখানে শুধু URL বদলে দিলেই হবে।

## ✅ Build ফিক্স সামারি (এই আপডেটে যা যা করা হয়েছে)

1. **AGP ভার্সন আপগ্রেড**: `com.android.application` প্লাগইন `8.2.2` → `8.5.2` (স্ট্যাবল, Codemagic/Android Studio উভয়ে ভালোভাবে সাপোর্টেড)
2. **Gradle Wrapper রিস্টোর**:
   - `gradle/wrapper/gradle-wrapper.properties` তৈরি করা হয়েছে (Gradle **8.7**, যেটা AGP 8.5.2-এর সাথে ম্যাচ করে)
   - `gradlew` (Linux/macOS) এবং `gradlew.bat` (Windows) স্ট্যান্ডার্ড স্ক্রিপ্ট হিসেবে যোগ করা হয়েছে, executable permission সহ
   - ⚠️ **`gradle-wrapper.jar` বাইনারি ফাইলটা এখানে জেনারেট করা যায়নি** — এই sandbox এনভায়রনমেন্টে ইন্টারনেট বন্ধ এবং Gradle ইন্সটল করা নেই, তাই অফিসিয়াল বাইনারি জার ডাউনলোড করার উপায় নেই। নিচে এটা ফিক্স করার সহজ উপায় দেওয়া আছে (Codemagic-এ এটা অটোমেটিক ফিক্স হয়ে যাবে)।
3. **codemagic.yaml** যোগ করা হয়েছে রুটে — এটা বিল্ডের শুরুতে `gradle wrapper --gradle-version 8.7` চালিয়ে wrapper jar নিজে থেকেই রিজেনারেট করে নেবে, তারপর `./gradlew clean assembleDebug` চালাবে
4. Gradle repositories, `settings.gradle`, `app/build.gradle` dependencies — সব ঠিকঠাক আছে, কোনো পরিবর্তনের দরকার হয়নি
5. Java কোড (`MainActivity.java`), লেআউট, ম্যানিফেস্ট, রিসোর্স XML — সব চেক করা হয়েছে, কোনো সিনট্যাক্স/কম্পাইল এরর পাওয়া যায়নি; **কোনো ফিচার বদল বা মুছে ফেলা হয়নি**

### Codemagic-এ বিল্ড
`codemagic.yaml` ফাইলটা রুটে আছে বলে Codemagic নিজে থেকেই এটা ধরবে। শুধু রিপো Codemagic-এ কানেক্ট করে "Start new build" চাপুন — `door-opener-android-debug` workflow টা wrapper রিজেনারেট করে APK বানিয়ে দেবে (আউটপুট: `app/build/outputs/apk/debug/app-debug.apk`)।

### লোকাল Android Studio-তে বিল্ড করার আগে একটা এক্সট্রা স্টেপ
যেহেতু `gradle-wrapper.jar` মিসিং, Android Studio-তে সরাসরি ওপেন করলে "Could not find or load main class org.gradle.wrapper.GradleWrapperMain" এরর দিতে পারে। এটা এড়াতে, প্রজেক্ট ওপেন করার **আগে** টার্মিনালে (একবারই) এই কমান্ডটা চালান:

```bash
# আপনার কম্পিউটারে Gradle ইন্সটল থাকতে হবে (https://gradle.org/install/ অথবা SDKMAN দিয়ে)
cd DoorOpener
gradle wrapper --gradle-version 8.7 --distribution-type bin
```

এটা অফিসিয়াল `gradle-wrapper.jar` সহ সবকিছু ঠিকভাবে জেনারেট করে দেবে। এরপর থেকে Android Studio-তে সরাসরি ওপেন করে Build > Build APK(s) কাজ করবে, এবং `./gradlew assembleDebug` টার্মিনাল থেকেও চলবে।

## গুরুত্বপূর্ণ নোট
- ফোনটা অবশ্যই সেই WiFi নেটওয়ার্কে কানেক্টেড থাকতে হবে যেখানে 192.168.68.106 ডিভাইসটি আছে (এটা একটা লোকাল/প্রাইভেট IP)
- এই কন্টেইনার এনভায়রনমেন্টে Android SDK/Gradle না থাকা এবং ইন্টারনেট বন্ধ থাকায় আমি নিজে সরাসরি .apk ফাইল কম্পাইল করে দিতে পারিনি — এই সোর্স কোড থেকে আপনাকে Android Studio দিয়ে বিল্ড করে নিতে হবে।
- বিকল্প হিসেবে, আপনি চাইলে অনলাইন কোনো APK বিল্ড সার্ভিস (যেমন GitHub Actions দিয়ে নিজের রিপোতে বিল্ড) ব্যবহার করেও এই একই সোর্স কোড দিয়ে APK বানাতে পারেন।
